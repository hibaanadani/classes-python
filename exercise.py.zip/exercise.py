class Animal:
  def __init__(self, color, age):
    self.color = color
    self.age = age
    self.__health = 0

  def sleep(self):
    self.__health += 15

  def eat(self):
    self.__health += 5

  def getHealth(self):
    return self.__health

  def setHealth(self, newHealth):
    self.__health = newHealth

  def increaseHealth(self, amount):
    self.__health += amount

  def decreaseHealth(self, amount):
    self.__health -= amount


class Bird(Animal):
  def __init__(self, color, age):
    self.isFlying = False
    super().__init__(color, age)

  def fly(self):
    super().decreaseHealth(5)

  # overriding
  def eat(self):
    super().eat()
    super().increaseHealth(5)


class Fish(Animal):
  def __init__(self, color, age):
    self.isInGroup = False
    super().__init__(color, age)

  def swim(self):
    super().decreaseHealth(7)


  def eat(self):
    super().eat()
    super().increaseHealth(7)


class Mammal(Animal):
  def __init__(self, color, age):
    super().__init__(color, age)

  def run(self):
    super().decreaseHealth(4)


  def eat(self):
    super().eat()
    super().increaseHealth(7)

parrot = Bird("Red", 1.5)
lion = Mammal("Brown", 4)
salmon = Fish("Yellow", 2)

def logInsights():
  print(f"Parrot: {parrot.getHealth()}")
  print(f"Lion: {lion.getHealth()}")
  print(f"Salmon: {salmon.getHealth()}")
  print("===================")


parrot.sleep()
lion.sleep()
salmon.sleep()

logInsights()

parrot.fly()
lion.run()
salmon.swim()

logInsights()

parrot.fly()
lion.run()
salmon.swim()

logInsights()

parrot.eat()
lion.eat()
salmon.eat()

logInsights()