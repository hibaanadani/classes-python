def initReceipt():
  name = input("Name: ")
  date = input("Date: ")

  receipt = {
    "user": name,
    "created": date,
  }

  return receipt

def createItems():
  items = []
  newItem = input("New item: ")

  while newItem != "exit":
    price = float(input(f"Enter the price {newItem}: "))

    item = {
      "name": newItem,
      "price": price,
    }

    items.append(item)

    newItem = input("New item: ")

  return items

# finds the sum of items passed in the parameters
def findSum(list):
  sum = 0

  for item in list:
    # item => { "name": string, "price": float }
    sum += item["price"]

  return sum


action = "yes"
list = []

while action != "no":
  newReceipt = initReceipt()
  itemsList = createItems()
  total = findSum(itemsList)

  newReceipt["items"] = itemsList
  newReceipt["total"] = total

  list.append(newReceipt)

  action = input("Want to add another receipt? (Enter 'no' if not) ")


# Formatting
# for i in range(len(list)):
#   receipt = list[i]

#   print(f"Receipt for {receipt['user']} at {receipt['created']}")

#   for item in receipt["items"]:
#     print(f"{item['name']} ============ {item['price']}")