# def listSum(list):
#   sum = 0

#   for num in list:
#     sum += num # sum = sum + num

#   return sum

# numbers2 = [84, 45, 96, 45]
# numbers = [24, 45, 94, 82]

# sumOfNumbers = listSum(numbers)

# print(sumOfNumbers)
# # listSum(numbers2)

# length = len(numbers)

# words = ["hss", "aa", "tat"]

# search = "aa"
# index = 0
# for word in words:
#   if word != search:
#     index += 1
#     print("Not found")
#   else:
#     break

# print(words[index])

for x in range(6):
  if x == 8:
    print(x)
else:
  print("Finally finished!")