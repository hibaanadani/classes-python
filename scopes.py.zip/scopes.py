# Checks if a word is a palindrome => Boolean
def isPalindrome(word):
  for i in range(len(word) // 2):
    if word[i] != word[-1 -i]:
      return False

  return True

print(isPalindrome("racecar"))



# Checks two words if they are an anagram => Boolean
# def isAnagram(first, second):