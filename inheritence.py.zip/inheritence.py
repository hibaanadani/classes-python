employees = []

class Employee:
  def __init__(self, name, salary):
    self.name = name
    self.salary = salary

  def display(self):
    print(f"Name: {self.name}")
    print(f"Salary: {self.salary}")

class Manager(Employee):
  def __init__(self, name, salary, dep):
    self.department = dep
    super().__init__(name, salary)

  def hireEmployee(self, newEmployee):
    employees.append(newEmployee)

class Chief(Manager):
  def __init__(self, name, salary, dep, position):
    self.position = position
    super().__init__(name, salary, dep)

emp1 = Manager("Taha", 3000, "Tech")
emp2 = Employee("Nabiha", 1800)

emp1.display()

# emp1.hireEmployee(emp2)

# print(employees)