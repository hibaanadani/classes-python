class Node:
  def __init__(self, data):
    self.data = data
    self.next = None


class LinkedList:
  def __init__(self):
    self.head = None
    self.length = 0

  def isEmpty(self):
    return self.head == None

  def addNode(self, node):
    if self.isEmpty():
      self.head = node
    elif self.length == 1:
      self.head.next = node
    else:
      current = self.head

      while current.next != None:
        current = current.next

      current.next = node

    self.length += 1

  def search(self, data):
    current = self.head

    while current != None:
      if current.data == data:
        break

      current = current.next

    return current

  def printList(self):
    current = self.head

    while current != None:
      print(current.data)

      current = current.next

  def removeNode(self, value):
    if self.isEmpty():
      return None

    current = self.head
    prev = None

    if current.data == value:
      self.head = current.next
      current.next = None

      self.length -= 1

      return current

    while current != None:
      if current.data == value:
        prev.next = current.next
        current.next = None

        self.length -= 1
        return current

      prev = current
      current = current.next

    # return None

    # ============ 2nd method with prev pointer ==============
    # while current != None:
    #   if current.next.data == value:
    #     temp = current.next
    #     current.next = current.next.next

    #     temp.next = None

    #     break

    #   current = current.next




list = LinkedList()

list.addNode(Node(12))
list.addNode(Node(24))
list.addNode(Node(5))
list.addNode(Node(32))
list.addNode(Node(18))

print("====== Print ======")
list.printList()

print("====== Length ======")
print(f"Length of list is: {list.length}")

print("====== Search ======")
result = list.search(32)

if result != None:
  print(result.data)
else:
  print("Not found")

print("====== Remove ======")

removed = list.removeNode(5)
removed = list.removeNode(12)
removed = list.removeNode(18)
removed = list.removeNode(24)
removed = list.removeNode(32)
print(f"Length = {list.length}")
list.printList()