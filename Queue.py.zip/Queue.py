class Node:
  def __init__(self, data):
    self.data = data
    self.next = None

class Queue:
  def __init__(self):
    self.head = None
    self.tail = None

  def isEmpty(self):
    return self.head == None and self.tail == None

  def enqueue(self, node):
    if self.isEmpty():
      self.head = node
      self.tail = node
    else:
      self.tail.next = node
      self.tail = node

  def dequeue(self):
    if self.isEmpty():
      return None
    else:
      temp = self.head

      self.head = temp.next
      temp.next = None

      return temp

  def printQueue(self):
    current = self.head

    while current != None:
      print(current.data)

      current = current.next

q = Queue()

q.enqueue(Node(1))
q.enqueue(Node(2))
q.enqueue(Node(3))
q.enqueue(Node(4))
q.enqueue(Node(5))

q.printQueue()
removed = q.dequeue()
print("========")
q.printQueue()