class BankAccount:
  def __init__(self, name):
    self.balance = 0
    self.user = name

  def deposit(self, amount):
    self.balance += amount

  def withdraw(self, amount):
    if self.balance > amount:
      self.balance -= amount
    else:
      print("Insuffecient balance")

  def transfer(self, amount, targetAccount):
    if self.balance > amount:
      self.balance -= amount
      targetAccount.deposit(amount)
    else:
      print("Insuffecient balance")


# acc1 = BankAccount("Taha")
# acc2 = BankAccount("Nabiha")

# print(f"Account 1: {acc1.balance}")
# print(f"Account 2: {acc2.balance}")

# acc1.deposit(100)
# print(f"Account 1: {acc1.balance}")
# print(f"Account 2: {acc2.balance}")

# acc1.transfer(30, acc1)
# print(f"Account 1: {acc1.balance}")
# print(f"Account 2: {acc2.balance}")

def prompt():
  print("================================")
  print("Select from the below menu:")
  print("1 ==> To create a new account")
  print("2 ==> To deposit in account")
  print("3 ==> To withdraw from account")
  print("4 ==> To view account")
  print("5 ==> To transfer to another account")
  print("6 ==> To exit account")

  action = int(input("Choice: "))
  print("================================")

  return action

def createAccount():
  name = input("Enter your name to create the account with: ")
  account = BankAccount(name)

  return account

def deposit():
  amount = float(input("Enter the amount to deposit: "))
  account.deposit(amount)

def withdraw():
  amount = float(input("Enter the amount to withdraw: "))
  account.withdraw(amount)

def logAccount():
  print(f"User: {account.user}")
  print(f"balance: {account.balance}")

def transfer():
  search = input("Enter the name of the user to transfer to his/her account: ")
  target = None

  for acc in accountsList:
    if acc.user == search:
      target = acc

  if target != None:
    amount = float(input(f"Enter the amount to transfer to {target.user}: "))
    account.transfer(amount, target)
  else:
    print("User not found")


# ======================= Program Starts Here =======================
accountsList = [
  BankAccount("Taha"),
  BankAccount("Charbel"),
  BankAccount("Maria"),
]
action = 0
previousAction = None
account = None

while action != 6:
  if previousAction != None:
    action = previousAction
    previousAction = None
    print(f"Doing action {action} from previous iteration")
  else:
    action = prompt()

  if account == None and action != 1 and action != 6:
    print("Create an account first:")
    previousAction = action
    action = 1

  if action == 1:
    account = createAccount()
  elif action == 2:
    deposit()
  elif action == 3:
    withdraw()
  elif action == 4:
    logAccount()
  elif action == 5:
    transfer()
  elif action == 6:
    print("Program Exit")



