class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class LinkedList:
    def __init__(self):
        self.head = None
#I am not sure if we should keep the method name as append or change it to add or addNode
#since append is used mainly in lists not linked Lists
    def append(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next!=None:
                current = current.next
            current.next = new_node