class Queue:
    def __init__(self):
        self.items = []
    
    def enqueue(self, item):
        self.items.append(item)

    def dequeue(self):
        if not self.items:
            raise IndexError("Queue is empty")
        return self.items.pop()

#the logical error here is that when we are dequeueing in the method,
#we are popping the last element from the list and not the first.
#which is not following the FIFO principle of a queue.
#to fix it we can use pop(0) which is giving the index of the first element in the list.
