class Car:
    def __init__(self,fuel,milage,fuel_consumption_rate):
        self.__fuel = fuel
        self.milage = milage
        self.fuel_consumption_rate = float(fuel_consumption_rate)

    def travel(self,distance):
        fuel_needed = distance * self.fuel_consumption_rate
        if fuel_needed<=self.fuel:
            self.fuel-=fuel_needed
            print(f"{distance} traveled fully")
        else:
            self.fuel-=fuel_needed
            print(f"{distance} not comlete, car stopped without reaching destination")

    def refuel(self,amount):
        self.fuel+=amount
        print(f"{amount} Liters added of fuel")
    
    def get_remaining_range(self):
        #fuel consumption=fuel*km
        remaining_range = self.fuel_consumption_rate/self.fuel
        return remaining_range
    
    def set_fuel(self,fuel):
        self.fuel = fuel
    
    def get_fuel(self):
        return self.fuel



        