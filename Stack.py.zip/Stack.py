class Node:
  def __init__(self, data):
    self.data = data
    self.next = None

class Stack:
  def __init__(self):
    self.head = None

  def isEmpty(self):
    return self.head == None

  def printStack(self):
    current = self.head

    while current != None:
      print(current.data)

      current = current.next

  def push(self, node):
    node.next = self.head
    self.head = node

  def pop(self):
    if self.isEmpty():
      return

    temp = self.head
    self.head = self.head.next
    temp.next = None

    return temp

s = Stack()

print("===== Pushing =====")
s.push(Node(5))
s.push(Node(55))
s.push(Node(51))
s.push(Node(57))

s.printStack()

print("===== Pop =====")

s.pop()
s.pop()

s.printStack()