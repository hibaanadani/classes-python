name = input("Please enter your name: ")
year = input("Please enter your year of birth: ")

age = 2025 - int(year)

print(name, "is", age, "years old")