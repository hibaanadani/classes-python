# age = int(input("Please enter your age: "))

# check = age > 15

# if check:
#   print("You can run this code")
# else:
#   print("Unauthorized")

# print("Program is done")

grade = float(input("Please enter your grade: "))

# if grade > 90:
#   print("A")
# else:
#   if grade > 80:
#     print("B")
#   else:
#     if grade > 70:
#       print("C")
#     else:
#       if grade > 60:
#         print("D")
#       else:
#         print("F")

if grade >= 90:
  print("A")
elif grade >= 80:
  print("B")
elif grade >= 70:
  print("C")
elif grade >= 60:
  print("D")
else:
  print("F")

# password = input("Enter a password: ")

# if len(password) >= 10:
#   print("Long")
# else:
#   print("Short")

# word = input("Enter a word: ")

# if word == "tahataha100":
#   print("Password correct")
# else:
#   print("Incorrect")