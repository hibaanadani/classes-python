class User:
  def __init__(self, name, password):
    self.name = name
    self.password = password

class BankAccount:
  def __init__(self, user):
    self.user = user
    # self._balance = 0 # This is a private attribute (preferable not to access outside the class but can), prefixed with single _
    self.__balance = 0 # This is a private attribute (cannot be accessed outside the class), prefixed with double _

  # Adding amount to balance
  def deposit(self, amount):
    self.__balance += amount

  # Check if the amount is available in the balance to withdraw
  def withdraw(self, amount):
    if self.__balance > amount:
      self.__balance -= amount
    else:
      print("Insufficient amount")

  # Passing another instance of BankAccout class in target Account so that we can access its own deposite method to add the transfered amount
  def transfer(self, amount, targetAccount):
    if self.__balance > amount:
      self.__balance -= amount
      targetAccount.deposit(amount)
    else:
      print("Insufficient amount")

  # Getter for the private attribute balance to access it outside
  def getBalance(self):
    return self.__balance

  # Setter for the private attribute balance to access it outside
  def setBalance(self, newBalance):
    self.__balance = newBalance


# acc1 = BankAccount("Taha")
# acc2 = BankAccount("Nabiha")

# def printAccounts(action):
#   print(f"Doing {action}")
#   print(f"Account 1: {acc1.balance}")
#   print(f"Account 2: {acc2.balance}")
#   print(f"===========================")

# printAccounts("Initial")

# acc1.deposit(100)
# printAccounts("Deposit to Account 1")

# acc1.transfer(70, acc2)
# printAccounts("Transfer from account 1 to 2")

# Creating a new instance
def createAccount():
  name = input("Enter your name that will be used in your account: ")
  password = input("Password: ")

  user = User(name, password)

  account = BankAccount(user)
  print(f"Created an account with balance 0 for {name}")

  accountsList.append(account)

  return account

def deposit():
  amount = float(input("Enter your deposit amount: "))
  account.deposit(amount)

def withdraw():
  amount = float(input("Enter your withdraw amount: "))
  account.withdraw(amount)

# Finding the target account to transfer to according to the name of the ser for each account from the above list of accounts
def transfer():
  name = input("Enter the user's name to transfer to his/her account: ")
  target = None

  for i in range(len(accountsList)):
    if accountsList[i].user.name == name:
      target = accountsList[i]

  if target == None:
    print("Account not found")
  else:
    amount = float(input("Enter your transfer amount: "))
    account.transfer(amount, target)

def printAccount():
  print(f"User: {account.user.name}")
  print(f"Balance: {account.getBalance()}")

def prompt():
  print("======================")
  print("Enter 0 to create an account")
  print("Enter 1 to deposit")
  print("Enter 2 to withdraw")
  print("Enter 3 to transfer")
  print("Enter 4 to check your account")
  print("Enter 5 to exit")
  action = int(input("Choice: "))
  print("======================")

  return action

def viewAccounts():
  for acc in accountsList:
      print(f"{acc.user.name}.......... ${acc.getBalance()}")

def switchAccount():
  name = input("Enter the user's name to switch accounts: ")

  target = None

  for acc in accountsList:
    if acc.user.name == name:
      target = acc
  if target == None:
    print("Account not found")
  else:
    password = input("Password: ")
    if target.user.password == password:
      return target
    else:
      print("Invalid Credentials")


# To transfer to
accountsList = []

action = ""
previousAction = None
account = None

while action != 5:
  if previousAction != None:
    action = previousAction
    previousAction = None
  else:
    action = prompt()

  if account == None and action != 0 and action != 5:
    choice = input("You don't have a current account, would you like to create a new one? ")

    if choice == "yes":
      previousAction = action
      action = 0
    else:
      print("Please create an account before applying any action")
      action = ""

  if action == 0:
    account = createAccount()
  elif action == 1:
    deposit()
  elif action == 2:
    withdraw()
  elif action == 3:
    transfer()
  elif action == 4:
    printAccount()
  elif action == 5:
    print("Program Exit")
  elif action == 6:
    viewAccounts()
  elif action == 7:
    account = switchAccount()
  elif action == 8:
    account = None
