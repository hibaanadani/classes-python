# users = []

# name = input("Enter name: ")
# password = input("Password: ")

# while name != "stop":
#   user = {
#     "name": name,
#     "password": password,
#   }

#   users.append(user)

#   name = input("Enter name: ")

#   if name != "stop":
#     password = input("Password: ")

# print(users)

# user = {
#   "password": "102030",
#   "name": "taha",
# }

# user["name"]

action = "yes"
list = []

while action != "no":
  name = input("Name: ")
  date = input("Date: ")

  receipt = {
    "user": name,
    "created": date,
  }

  items = []
  sum = 0
  newItem = input("New item: ")
  while newItem != "exit":
    price = float(input(f"Enter the price {newItem}: "))
    sum = sum + price

    item = {
      "name": newItem,
      "price": price,
    }

    items.append(item)

    newItem = input("New item: ")

  receipt["items"] = items
  receipt["total"] = sum

  list.append(receipt)

  action = input("Want to add another receipt? (Enter 'no' if not) ")


# Formatting
for i in range(len(list)):
  receipt = list[i]

  print(f"Receipt for {receipt['user']} at {receipt['created']}")
  for item in receipt["items"]:
    print(f"{item['name']} ============ {item['price']}")