# user1 = {
#   "username": "Taha",
#   "password": "1234",
# }

# user2 = {
#   "username": "Taha",
#   "password": "1234",
# }


# users = [user1, user2]

# for i in range(len(users)):
#   users[i]["username"]

class User:
  name = ""
  age = 0

  def __init__(self, name, age):
    self.name = name
    self.age = age

  def logUser(self):
    print(self.name)



user1 = User("taha", 40)
user2 = User("nabiha", 30)
