print("Menu: ")
print("1: to add a new grade")
print("2: to find the average")
print("3: view grades")
print("4: to resest")
print("5: to quit")

action = int(input("Enter an option: "))
grades = []

while action != 5:
  if action == 1:
    newGrade = input("Enter new grade: ")
    grades.append(int(newGrade))

  elif action == 2:
    sum = 0
    average = 0

    for grade in grades:
      sum = sum + grade

    if len(grades) !=0:
      average = sum / len(grades)

    print(f"Average is {average}")

  elif action == 3:
    for current in grades:
      print(current)

  elif action == 4:
    grades.clear()
    print("Reset")

  action = int(input("Enter an option: "))

print("Exit")