list = []

for i in range(5):
  name = input("Enter a new name: ")
  list.append(name)

print(list)

search = input("Enter your search keyword: ")

for i in range(len(list)):
  if search == list[i]:
    print(f'The search keyword is at position "" {{i}}')

# ===============================================================

name = input("Enter a new name: ")

while name != "stop":
  list.append(name)
  name = input("Enter a new name: ")

print(list)